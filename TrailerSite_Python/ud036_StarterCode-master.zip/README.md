# ud036_StarterCode
Source code for a Movie Trailer website.
# **Frest Tomatoes Trailer**
This project makes a static website which *Displays movie posters and trailers*.

# **Usage**
*With the terminal:*
>1. Clone the directory
>2. Navigate to directory cd REPOSITORY-NAME
>3. Run python `entertainment_center.py`

*IDLE:*
>4. Open IDLE
>5. In the menu bar click on Run -> Run Module or press F5 on your keyboard.

# **Modules**
The modules present in this proect are
1. **media**.py 
> It defines instances and methods for the class.
2. **entertainment_center**.py 
> It is used to visit the site and also contains the movies that are displayed on the site. It importes media and fresh_tomatoes.
3. **fresh_tomatoes**.py 
> It builds the **HTML** and the **CSS** content of the site and also opens the youtube windows in a floating windows.